#!/bin/sh

adb root
adb wait-for-device
adb remount

version=$(adb shell getprop |grep ro.vendor.build.version.release)
if [ "$version" = "[ro.vendor.build.version.release]: [9]" ]; then
    echo "Android Pie"
else
    echo ">>> $version"
    echo "Not Android Pie, not supported"
    exit
fi
apkmanager=MagiskManager-v7.4.0.apk
apkxposed=XposedInstaller_by_dvdandroid_19_10_18.apk
magisk=Magisk-v20.0.zip
riru=magisk-riru-core-v11.zip
riru=magisk-riru-core-v11.zip
xposed=magisk-EdXposed-v0.2.9.6_beta-release.zip

adb push $magisk /sdcard/
adb push $riru /sdcard/
adb push $xposed /sdcard/
adb push $riru /sdcard/
echo "busybox unzip /sdcard/$magisk -d /data/misc/media"
adb shell "busybox unzip -o /sdcard/$magisk -d /data/misc/media"

echo "chmod 777 /data/misc/media/META-INF/com/google/android/*"
adb shell "chmod 777 /data/misc/media/META-INF/com/google/android/*"
echo "/data/misc/media/META-INF/com/google/android/updater-script"
adb shell "export INSTALLER=/data/misc/media && /data/misc/media/META-INF/com/google/android/updater-script"
adb install -r $apkmanager
adb install -r $apkxposed
#adb reboot
