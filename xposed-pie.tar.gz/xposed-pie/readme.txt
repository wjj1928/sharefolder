1. use android-9.0 (pie) device with userdebug build.
2. make sure adb remount sucess (adb disable-verity executed).
3. Connect to device with usb-c cable, run install.sh from linux or macosx.
4. reboot device.
5. run MagiskManager app,following prompt dialog to do initialize.
6. reboot device. then run MagiskManager menu->module to install module "/sdcard/magisk-riru-core-v11.zip"
7. reboot device. then run MagiskManager menu->module to install module "/sdcard/magisk-EdXposed-v0.2.9.6_beta-release.zip".
8. reboot device. then run xposed Installer to install xposed modules.
9. select installed modules from xposed menu->module. reboot device.
Enjoy.xposed module should be actived.
